#!/usr/local/bin/python3

import os
import sys
import boto3
import logging
from datetime import datetime, timedelta
from time import sleep
from pymongo import MongoClient

AWS_REGION = os.environ.get("AWS_REGION", "us-west-2")
TIMESTAMP_FORMAT = "%Y-%m-%dT%H:%M:%S.%fZ"
ENVIRONMENT = os.environ.get("ENVIRONMENT")
DEVICE_NAME = os.environ.get("DEVICE_NAME")
DB_HOST = os.environ.get("DB_HOST")
DB_DATABASE = os.environ.get("DB_DATABASE")
DB_REPLSET = os.environ.get("DB_REPLSET")
DB_USER = os.environ.get("DB_USER")
DB_PASSWORD = os.environ.get("DB_PASSWORD")
CMD_IS_PRIMARY = 'mongo --quiet {0} --eval "rs.isMaster().ismaster"'.format(DB_HOST)
CMD_FSYNC_LOCK = 'mongo {0} -u {1} -p {2} --eval "db.fsyncLock()"'.format(DB_HOST, DB_USER, DB_PASSWORD)
CMD_FSYNC_UNLOCK = 'mongo {0} -u {1} -p {2} --eval "db.fsyncUnlock()"'.format(DB_HOST, DB_USER, DB_PASSWORD)

ec2 = boto3.resource('ec2', region_name=AWS_REGION)
logger = logging.getLogger()
logger.setLevel(logging.INFO)

def get_node_instance_id(hostname):
  instances = ec2.instances.filter(Filters=[
    {'Name': 'tag:Environment', 'Values': [ENVIRONMENT]},
    {'Name': 'tag:Hostname', 'Values': [hostname]}
  ])
  for i in instances:
    return i.id
  logging.critical("No instance could be found with tag {0}".format(hostname))
  sys.exit(1)   

def get_snapshot_volume(volumes, device_name):
  for vol in volumes:
    for device in vol.attachments:
      if device["Device"] == device_name:
        logger.info("Detected MongoDB volume: {0}".format(vol.id))
        return vol

  logger.critical("No attached volume could be found for {0}".format(device_name))
  sys.exit(1)

def create_snapshot(db_node, device_name, env, snapshot_name):
  instance_id = get_node_instance_id(db_node)

  # Fetch the volume id mapped to the mongodb data device
  volumes = ec2.volumes.filter(Filters=[
    {'Name': 'attachment.instance-id', 'Values': [instance_id]},
    {'Name': 'attachment.device', 'Values': [device_name]},
  ])
  mongo_vol = get_snapshot_volume(volumes = volumes, device_name = device_name)
  logger.info("Taking a snapshot of {vol_id} and calling it {snap_name}".format(
      vol_id=mongo_vol.id,
      snap_name=snapshot_name
    )
  )

  # create new snapshot
  new_snap = ec2.create_snapshot(
    Description="MongoDB snapshot from {0} host {1}".format(env, db_node),
    VolumeId=mongo_vol.id,
    TagSpecifications=[
        {
            'ResourceType': 'snapshot',
            'Tags': [
                {
                    'Key': 'Name',
                    'Value': snapshot_name
                }, {
                    'Key': 'Env',
                    'Value': env
                }, {
                    'Key': 'Device',
                    'Value': device_name                  
                }
            ]
        },
    ]
  )
  logger.info("Snapshot {snap_id} created".format(
      snap_id=new_snap.id
    )
  )

def lambda_handler(event, context):
  logger.info("Lambda execution starting...")
  replset_client = MongoClient(DB_HOST, username=DB_USER, password=DB_PASSWORD,
                  replicaset=DB_REPLSET, readPreference="secondary")
  sleep(0.5)
  replset_nodes = replset_client.nodes
  replset_client.close()

  for (node, port) in replset_nodes:
    logger.info("Processing node {0}".format(node))
    c = MongoClient(node, port, username=DB_USER, password=DB_PASSWORD)
    if c.is_primary:
      c.close()
      continue
    else:
      # lock the secondary
      # print("locked before:", c.is_locked)
      options = {'lock': True}
      c.fsync(**options)

      # create snapshot
      # print("locked mid:", c.is_locked)
      create_snapshot(
        node, env = ENVIRONMENT,
        device_name = DEVICE_NAME,
        snapshot_name = "mongo_{0}_{1}".format(ENVIRONMENT, datetime.now().isoformat())
      )

      # unlock the secondary
      c.unlock()
      # print("locked after:", c.is_locked)
      
      # close the connection
      c.close()
      break